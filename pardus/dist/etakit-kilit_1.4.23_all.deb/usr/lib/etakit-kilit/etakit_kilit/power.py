"""Kapatma ve oturum sonlandırma. Etkin oturum polkit kuralıyla parola sormadan kapanır."""

from __future__ import annotations

import os
import subprocess


def logout_user(run=None, environ: dict[str, str] | None = None) -> bool:
    """Grafik oturumu kapatır."""
    env = os.environ if environ is None else environ
    runner = run or subprocess.run
    commands = [["xfce4-session-logout", "--logout", "--fast"]]
    session_id = str(env.get("XDG_SESSION_ID") or "").strip()
    if session_id:
        commands.append(["loginctl", "terminate-session", session_id])
    uid = str(env.get("UID") or "").strip()
    if not uid:
        getuid = getattr(os, "getuid", None)
        if getuid is not None:
            try:
                uid = str(getuid())
            except OSError:
                uid = ""
    if uid:
        commands.append(["loginctl", "terminate-user", uid])
    for command in commands:
        try:
            result = runner(command, capture_output=True, timeout=20, check=False)
        except (OSError, subprocess.TimeoutExpired):
            continue
        if getattr(result, "returncode", 1) == 0:
            return True
    return False


def poweroff() -> bool:
    for command in (["loginctl", "poweroff"], ["systemctl", "poweroff"]):
        try:
            result = subprocess.run(command, capture_output=True, timeout=20, check=False)
        except (OSError, subprocess.TimeoutExpired):
            continue
        if result.returncode == 0:
            return True
    return False
